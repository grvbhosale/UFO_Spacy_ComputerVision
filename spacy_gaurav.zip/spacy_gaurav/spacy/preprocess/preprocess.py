import cv2
import numpy as np
import classifier

class Localize:

    def process(self, image):
        """
        Todo:
        preprocess frame to find out the location of UFO's.
        sort them from top to bottom based on their location,
        crop the UFO image from original frame and pass it to classifier.
        submit the predicted numbers list.
        """

        ################## Please write your code here ###################
        #canny(frame)  #some of the previous atempts
        #detectblob(frame)
        #adaptive (frame)
        ##################################################################

        '''
        Used various thresholding , filtering etc but since the image was already computer generated most of them actually decreased detections.
        '''

        edge_detected_image = cv2.Canny(image, 75, 200) # used canny to detect edges (found using bilinear filter decresed accuracy due the fact that this was syntethic image with strong edges.)
        contours, hierarchy = cv2.findContours(edge_detected_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)#find contours to detect ufos and numbers withint it.
        contours = sorted(contours, key=lambda contours: cv2.boundingRect(contours)[1])#sort them by y value

        '''
        the above code is just to get contours from images and sort them
        '''

        contour_list = []# to store contours
        for i,c in enumerate(contours):
            peri = cv2.arcLength(c,True)
            approx = cv2.approxPolyDP(c,0.05*peri,True)
            x,y,w,h = cv2.boundingRect(c)
            aspectRatio = w / float(h)
            area = cv2.contourArea(c)
            if (aspectRatio > 0.07) and (aspectRatio < 0.95) :
                if (area < 200) and (area>30) :# the idea use to filter out contours based on their asspect ratio and area. The contours we are looking out are contours of the numbers inside the ufo . so small rectangular contours.
                    contour_list.append(c)

        '''
        The above code is for selecting the right contours based on aspect ratio and area
        '''

        crop=[] # to store crops
        init_y=0 #to store y values
        for c in contour_list:
            x,y,w,h = cv2.boundingRect(c)
            y = (cv2.boundingRect(c)[1])
            if (init_y+30 >= y) and (y>= init_y-30) :#this so that any spurrious boxes near the ufo are eliminated . We can also do this on x axis or use NMS or hierarchy of contours
                init_y = y
            elif(y==72):
                print('exception!')
            else:
                init_y = y
                roi = image[y-(25):y+(30), x-(35):x+(46)]#crop the image changing any of these values will degrade classification accuracy as svm isnt robustly trained.
                cv2.rectangle(image,((x-(45)),(y-(33))),(x+(53),y+(39)),(0,0,255),2)#bounding box for visual cues
                crop.append(roi)
                roi = cv2.resize(roi,(170,115))#not needed but was used for peace of mind

        '''
        The above code is for removing extra bounding boxes and cropping
        '''

        crop1 = crop[0] # we can use just pass x,y values instead of passing the whole image each time although we are passing crops here since the size isnt that big
        crop2 = crop[1]
        crop3 = crop[2]
        try :
            crop4 = crop[3] #sometimes the lowest ufo isnt detected and this causes the program to crash
        except:
            crop4= crop[2]
            pass

        '''
        The above code is for just passing the crops to classifier passing  crop1=crop[0] isnt required but is required for crop4 due to sometimes problem localizing which might cause crash.
        Also since we have already sorted them by y values
        '''
        myanswer = classifier.predict(images=[crop1,crop2,crop3,crop4])
        contour_list.clear()
        crop.clear()
        return myanswer

localize = Localize()
