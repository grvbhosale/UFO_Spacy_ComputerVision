from classifier.classifier import classifier
predict = classifier.predict